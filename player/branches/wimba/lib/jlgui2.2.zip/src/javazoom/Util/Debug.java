package javazoom.Util;

import java.io.*;
import java.util.*;

/**
 * This class implements a simple Debug Tool.
 *
 * @author	E.B from JavaZOOM
 * @date	07/10/2001
 *
 * Homepage : http://www.javazoom.net
 *
 *-----------------------------------------------------------------------
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *----------------------------------------------------------------------
 */

public class Debug
{
  private static Debug _instance = null;
  private PrintWriter _out = null;
  private int _loglevel = 0;

  private Debug()
  {}

  /**
   * Returns Debug instance.
   */
  public synchronized static Debug getInstance()
  {
    if (_instance == null)
    {
      _instance = new Debug();
    }
    return _instance;
  }

  /**
   * Inits log file.
   */
  public synchronized void init(String filename, int level)
  {
    _loglevel = level;
    try
    {
      _out = new PrintWriter(new FileOutputStream(filename));
    }
    catch (IOException ioe)
    {
      System.err.println("Cannot open log file : " + ioe.getMessage());
    }
  }

  /**
   * Closes log file.
   */
  public synchronized void close()
  {
    if (_out != null)
    {
      try
      {
        _out.flush();
        _out.close();
      }
      catch (Exception ioe)
      {
        System.err.println("Cannot close log file : " + ioe.getMessage());
      }
    }
  }

  /**
   * Sets log level.
   */
  public void setLogLevel(int level)
  {
    _loglevel = level;
  }

  /**
   * Sends message to log file.
   */
  public synchronized void log(int level, String msg)
  {
    if (_loglevel >= level)
    {
      if (_out != null)
      {
        _out.println(msg);
        _out.flush();
      }
      else
      {
        System.err.println(msg);
      }
    }
  }
}
