package javazoom.jlGui.playlist;

import javazoom.jlGui.tag.*;
import javazoom.Util.FileUtil;
import java.io.File;
import com.jcraft.jorbis.*;
import java.io.*;
import javazoom.Util.Debug;
import helliker.id3.*;
import javazoom.jl.decoder.*;

/**
 * PlaylistItem.
 *
 *-----------------------------------------------------------------------
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *----------------------------------------------------------------------
 *
 */
public class PlaylistItem
{
  protected String _name = null;
  protected String _displayName = null;
  protected String _location = null;
  protected boolean _isFile = true;
  protected long _seconds = -1;
  protected boolean _isSelected = false; // add by JOHN YANG
  protected TagInfo _taginfo = null;

  protected PlaylistItem()
  {
  }

  public PlaylistItem(String name, String location, long seconds, boolean isFile)
  {
    _name = name;
    _seconds = seconds;
    _isFile = isFile;
    setLocation(location);
  }

  /**
   * Returns item name such as (hh:mm:ss) Title - Artist if available.
   * @return
   */
  public String getFormattedName()
  {
    if (_displayName == null) return _name;
    else return _displayName;
  }

  public String getName()
  {
    return _name;
  }

  public String getLocation()
  {
    return _location;
  }

  /**
   * Returns true if item to play is coming for a file.
   * @return
   */
  public boolean isFile()
  {
    return _isFile;
  }

  /**
   * Returns playtime in seconds. If tag info is available then its playtime will be returned.
   * @return playtime
   */
  public long getLength()
  {
    if ((_taginfo != null) && (_taginfo.getPlayTime()>0)) return _taginfo.getPlayTime();
    else return _seconds;
  }

  public void setSelected(boolean mode)
  {
    _isSelected = mode;
  }

  public boolean isSelected()
  {
    return _isSelected;
  }

  /**
   * Reads file comments/tags.
   * @param l
   */
  public void setLocation(String l)
  {
    _location = l;

    // Check Audio Format.
    // This code should not be here but in JavaSound SPI, however
    // JavaSound API does not provide anything about TAGs :-(
    if (_isFile && _location != null)
    {
      // Check Mpeg format.
      try
      {
        _taginfo = new MpegInfo(l);
      }
      catch (ID3Exception ex)
      {
        trace(1, this.getClass().getName(), ex.getMessage());
        _taginfo = null;
      }
      catch (IOException ex)
      {
        trace(1, this.getClass().getName(), ex.getMessage());
        _taginfo = null;
      }
      catch (JavaLayerException ex)
      {
        // Not Mpeg Format
        _taginfo = null;
      }

      if (_taginfo == null)
      {
        // Check Ogg Vorbis format.
        try
        {
          _taginfo = new OggVorbisInfo(l);
        }
        catch (JOrbisException ex)
        {
          // Not Ogg Vorbis Format
          _taginfo = null;
        }
        catch (IOException ex)
        {
          trace(1, this.getClass().getName(), ex.getMessage());
          _taginfo = null;
        }
      }
    }
    _displayName = getFormattedDisplayName();
  }

  /**
   * Returns item lenght such as hh:mm:ss
   * @return formatted String.
   */
  public String getFormattedLength()
  {
    long time = this.getLength();
    String length = "";
    if (time > -1)
    {
      if (time >= 3600)
      {
        length = FileUtil.rightPadString( (time / 3600) + "", '0', 2)
            + ":";
        time -= 3600;
      }
      length = length
          + FileUtil.rightPadString( (time / 60) + "", '0', 2)
          + ":"
          + FileUtil.padString( (time % 60) + "", '0', 2);
    }
    else length = ""+time;
    return length;
  }

  /**
   * Returns item name such as (hh:mm:ss) Title - Artist
   * @return formatted String.
   */
  private String getFormattedDisplayName()
  {
    if (_taginfo == null) return null;
    else
    {
      String length = this.getFormattedLength();
      if ( (_taginfo.getTitle() != null) && (!_taginfo.getTitle().equals("")) &&
           (_taginfo.getArtist() != null) && (!_taginfo.getArtist().equals("")))
      {
        return ("("+length+") "+ _taginfo.getTitle() + " - " + _taginfo.getArtist());
      }
      else
      {
        return ("("+length+") " + _name);
      }
    }
  }

  /**
   * Return item name such as hh:mm:ss,Title,Artist
   * @return formatted String.
   */
  public String getM3UExtInf()
  {
    if (_taginfo == null)
    {
      return (_seconds + "," + _name);
    }
    else
    {
        return (this.getFormattedLength() + "," + _taginfo.getTitle() + " - " + _taginfo.getArtist());
    }
  }

  /**
   * Return TagInfo.
   * @return
   */
  public TagInfo getTagInfo()
  {
    return _taginfo;
  }

  /**
   * Sends traces to Debug.
   */
  private void trace(int level, String msg1, String msg2)
  {
    Debug dbg = Debug.getInstance();
    dbg.log(level, msg1 + ":" + msg2);
  }
}
