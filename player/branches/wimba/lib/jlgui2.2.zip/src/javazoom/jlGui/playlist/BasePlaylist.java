package javazoom.jlGui.playlist;

/**
 * BasePlaylist.
 *
 *-----------------------------------------------------------------------
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *----------------------------------------------------------------------
 */

import java.util.Collection;
import java.util.Vector;
import java.util.Iterator;
import java.io.*;
import javazoom.Util.*;
import java.net.*;

/**
 * BasePlaylist.
 * This class implements Playlist interface using a Vector.
 *
 * @author	E.B from JavaZOOM
 *
 * Homepage : http://www.javazoom.net
 */
public class BasePlaylist implements Playlist
{
  protected Vector _playlist = null;
  protected int _cursorPos = -1;
  public boolean isModified;

  /**
   * Constructor.
   */
  public BasePlaylist()
  {
    _playlist = new Vector();
  }

  public boolean isModified()
  {
    return isModified;
  }

  /**
   * Loads playlist as M3U format.
   */
  public boolean load(String filename)
  {
    setModified(true);

    Config config = Config.getInstance();
    _playlist = new Vector();
    boolean loaded = false;
    BufferedReader br = null;
    try
    {
      // Playlist from URL or File.
      if (filename.toLowerCase().startsWith("http"))
      {
        br = new BufferedReader(new InputStreamReader( (new URL(filename)).openStream()));
      }
      else
      {
        br = new BufferedReader(new FileReader(filename));
      }
      String line = null;
      String songName = null;
      String songFile = null;
      String songLenght = null;
      while ( (line = br.readLine()) != null)
      {
        if (line.startsWith("#"))
        {
          int indA = line.indexOf(",", 0);
          if (indA != -1)
          {
            songName = line.substring(indA + 1, line.length());
          }
        }
        else
        {
          boolean isFile = true;
          songFile = line;
          if (songFile.startsWith("http://"))
          {
            isFile = false;
            if (songName == null)
            {
              songName = songFile;
            }
          }
          if (songName == null)
          {
            songName = songFile;
            songName = songName.substring( (songName.lastIndexOf(System.getProperty("file.separator"))) + 1, songName.length());
          }
          PlaylistItem pli = new PlaylistItem(songName, songFile, -1, isFile);
          if (isFile)
          {
            File f = new File(pli.getLocation());
            // Absolute path
            if (f.exists())
            {
              this.appendItem(pli);
            }
            else
            {
              // Relative path to be WinAmp M3U compliant.
              f = new File(config.getLastDir() + pli.getLocation());
              if (f.exists())
              {
                pli.setLocation(config.getLastDir() + pli.getLocation());
                this.appendItem(pli);
              }
            }

          }
          else
          {
            this.appendItem(pli);
          }
          //this.appendItem(pli);
          songFile = null;
          songName = null;
          songLenght = null;
        }
      }
      loaded = true;
    }
    catch (Exception e)
    {
      trace(2, getClass().getName(), "Can't load playlist : " + e.getMessage());
    }
    finally
    {
      try
      {
        if (br != null)
        {
          br.close();
        }
      }
      catch (Exception ioe)
      {
        trace(1, getClass().getName(), "Can't close playlist : " + ioe.getMessage());
      }
    }
    return loaded;
  }

  /**
   * Saves playlist.
   */
  public boolean save(String filename)
  {
    // Implemented by C.K
    if (_playlist != null)
    {
      BufferedWriter bw = null;
      try
      {
        bw = new BufferedWriter(new FileWriter(filename));
        Iterator it = _playlist.iterator();
        while (it.hasNext())
        {
          PlaylistItem pli = (PlaylistItem) it.next();
          bw.write("#EXTINF:-1," + pli.getM3UExtInf());
          bw.newLine();
          bw.write(pli.getLocation());
          bw.newLine();
        }
        return true;
      }
      catch (IOException e)
      {
        trace(1, getClass().getName(), "Can't save playlist : " + e.getMessage());
      }
      finally
      {
        try
        {
          if (bw != null)
          {
            bw.close();
          }
        }
        catch (IOException ioe)
        {
          trace(1, getClass().getName(), "Can't close playlist : " + ioe.getMessage());
        }
      }
    }
    return false;
  }

  /**
   * Adds item at a given position in the playlist.
   */
  public void addItemAt(PlaylistItem pli, int pos)
  {
    _playlist.insertElementAt(pli, pos);
    setModified(true);
  }

  /**
   * Searchs and removes item from the playlist.
   */
  public void removeItem(PlaylistItem pli)
  {
    _playlist.remove(pli);
    setModified(true);
  }

  /**
   * Removes item at a given position from the playlist.
   */
  public void removeItemAt(int pos)
  {
    _playlist.removeElementAt(pos);
    setModified(true);
  }

  /**
   * Removes all items from the playlist.
   */
  public void removeAllItems()
  {
    _playlist.removeAllElements();
    _cursorPos = -1;
    setModified(true);
  }

  /**
   * Append item at the end of the playlist.
   */
  public void appendItem(PlaylistItem pli)
  {
    _playlist.addElement(pli);
    setModified(true);
  }

  /**
   * Sorts items of the playlist.
   */
  public void sortItems(int sortmode)
  {
    // TODO
  }

  /**
   * Shuffles items in the playlist randomly
   */
  public void shuffle()
  {
    int size = _playlist.size();

    if (size < 2)
    {
      return;
    }

    Vector v = _playlist;
    _playlist = new Vector(size);

    while ( (size = v.size()) > 0)
    {
      _playlist.addElement(v.remove( (int) (Math.random() * size)));

    }
    begin();
  }

  /**
   * Moves the cursor at the top of the playlist.
   */
  public void begin()
  {
    _cursorPos = -1;
    if (getPlaylistSize() > 0)
    {
      _cursorPos = 0;
    }
    setModified(true);
  }

  /**
   * Returns item at a given position from the playlist.
   */
  public PlaylistItem getItemAt(int pos)
  {
    PlaylistItem pli = null;
    pli = (PlaylistItem) _playlist.elementAt(pos);
    return pli;
  }

  /**
   * Returns a collection of playlist items.
   */
  public Collection getAllItems()
  {
    // TODO
    return null;
  }

  /**
   * Returns then number of items in the playlist.
   */
  public int getPlaylistSize()
  {
    return _playlist.size();
  }

  // Next methods will be used by the Player

  /**
   * Returns item matching to the cursor.
   */
  public PlaylistItem getCursor()
  {
    if ( (_cursorPos < 0) || (_cursorPos >= _playlist.size()))
    {
      return null;
    }
    return getItemAt(_cursorPos);
  }

  /**
   * Computes cursor position (next).
   */
  public void nextCursor()
  {
    _cursorPos++;
    if (_cursorPos >= _playlist.size())
    {
      _cursorPos = _playlist.size() - 1;
    }
  }

  /**
   * Computes cursor position (previous).
   */
  public void previousCursor()
  {
    _cursorPos--;
    if (_cursorPos < 0)
    {
      _cursorPos = 0;
    }
  }

  public boolean setModified(boolean set)
  {
    isModified = set;
    return isModified;
  }

  public void setCursor(int index)
  {
    _cursorPos = index;
  }

  /**
   * Returns selected index.
   */
  public int getSelectedIndex()
  {
    return _cursorPos;
  }

  /**
   * Returns index of playlist item.
   */
  public int getIndex(PlaylistItem pli)
  {
    int pos = -1;
    for (int i=0;i<_playlist.size();i++)
    {
      pos = i;
      PlaylistItem p = (PlaylistItem) _playlist.elementAt(i);
      if (p.equals(pli)) break;
    }
    return pos;
  }

  /**
   * Sends traces to Debug.
   */
  private void trace(int level, String msg1, String msg2)
  {
    Debug dbg = Debug.getInstance();
    dbg.log(level, msg1 + ":" + msg2);
  }
}