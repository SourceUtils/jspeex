---------------------------------------------------------
 jlGui : 100% JAVA music player.

 Project Homepage :
   http://www.javazoom.net/jlgui/jlgui.html

 MP3 & JAVA Forums :
   http://www.javazoom.net/services/forums/index.jsp

 JNLP (JavaWebStart) configurator :
   http://www.javazoom.net/jlgui/jnlp_configurator.jsp
---------------------------------------------------------

To launch jlGui just doucle click under jlGui2.2.jar. If nothing appears then edit jlGui.bat 
(or jlGui.sh) script and setup JLGUI_HOME variable before launching the script.

To play local file : Left click on "Eject" button.
To play load a new skin or playlist file : Left click on "Eject" button.
To play remote file/stream : Right click on "Eject" Button.
To fill in playlist : Edit default.m3u file before launching jlGui or use the playlist UI.

Have fun.


07/01/2003 : jlGui 2.2
----------------------
- OGG comments and ID3 tags viewer added.
- PlaylistUI up&down buttons added.
- Playlist interface improved.
   + setModified/isModified methods added.
   + setCursor method added.
- Shuffle implemented.
- VorbisSPI 0.7 included.
- JOrbis 0.0.12 included.
- MpegSPI 1.6 included.
  (It fixes WAV file non-playing bug under JDK 1.4).
- Bug fix in "Add dir" feature under Linux.
- Bug fix in AudioInputStream closing.


04/01/2002 : jlGui 2.1.1
------------------------
- Drag and Drop support added.
- WinAmp Skins 2.0 support improved.
   + Minimize button added.
   + Double-click to play song from playlist added.
   + Add files to playlist from directory added.
   + Popup menu on title bar added.
- MPEG 2.5 support added through JavaLayer 0.2.0.
- JavaWebStart support added.
   + Default skin included in JAR file.
   + jlgui.jnlp sample included.
- Configuration setup improved.
   + Load custom jlgui.ini from file or URL added.
   + Load skin from URL added.
   + Load playlist from URL added.
   + Optionally run the playlist on startup added.
- API improved and online samples added to help developers.
- jlGui.sh script bug fixed.
- M3U support bug fixed to be 100% compliant with WinAmp M3U.


03/04/2002 : jlGui 2.1
----------------------
- Playlist UI added.
   + Main window, Scrollbar, Add File/Url, Inv/Crop/Remove Selection.
- WinAmp Skins 2.0 support improved.
   + Audio files filter added.
   + Dynamic skin and playlist loading added.
   + Playlist, Shuffle, Repeat, Equalizer buttons.
- Configuration file "jlgui.ini" added.
- Ogg Vorbis streaming support improved (VorbisSPI 0.6 + JOrbis0.0.11).
- MpegAudioSPI improved :
   + SYNC offset support added => ID3 tags skipped.
   + BitRate + total length in seconds info returned.
- License moved from GPL to LGPL.


10/01/2001 : jlGui 2.0
----------------------
- MP3 streaming support for Shoutcast/Icecast added.
- Ogg Vorbis support added.
- Playlist implementation and M3U support added.
- JavaLayer 0.1.1 included to improve MP3 support.
- WinAmp Skins 2.0 support improved.
- Seek bar added (for WAV files only).


05/14/2000 : jlGui 1.0
----------------------
- jlGui is now open source (GPL).
- JavaLayer 0.0.8 included.
- MpegAudioSPI (from tritonus.org) included.
- 70% WinAmp skins compatible.
