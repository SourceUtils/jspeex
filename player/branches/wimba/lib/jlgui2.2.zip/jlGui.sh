#!/bin/sh
################################
#   jlGui Un*x Launch Script   #
#                              #
#   http://www.javazoom.net    #
################################
#Modify these variables as needed.

JAVA_HOME=/usr/local/java/jdk1.3
export JAVA_COMPILER=jitc
JLGUI_HOME=/home/javazoom/jlGui2.2
JAVALAYER=$JLGUI_HOME/lib/jl020.jar
MPEGSPI=$JLGUI_HOME/lib/mp3sp.1.6.jar
VORBISSPI=$JLGUI_HOME/lib/jorbis-0.0.12.jar:$JLGUI_HOME/lib/jogg-0.0.5.jar:$JLGUI_HOME/lib/vorbisspi0.7.jar
JID=$JLGUI_HOME/lib/jid3.jar
JLGUI=$JLGUI_HOME/jlGui2.2.jar
# You should not need to modify the script beyond this point.
# --------------------------------------------------------------------------
# PATH=$JAVA_HOME/bin
CLASSPATH=$JLGUI:$JAVALAYER:$MPEGSPI:$VORBISSPI:$JID
JAVA=$JAVA_HOME/bin/java
$JAVA -classpath $CLASSPATH javazoom.jlGui.Player -loglevel 1
# --------------------------------------------------------------------------